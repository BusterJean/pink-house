module.exports = {
  'styled-components': {
    pure: true
  }
} 