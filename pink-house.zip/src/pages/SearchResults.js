import React from 'react';

const SearchResults = () => {
  return (
    <div>
      <h1>Search Results</h1>
      <p>This is a placeholder for search results.</p>
    </div>
  );
};

export default SearchResults;
